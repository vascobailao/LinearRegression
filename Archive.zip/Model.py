import ntpath
import pandas as pd
import os

class Model:

    def __init__(self, input_dir, ext):
        self.input_dir = input_dir
        self.ext = ext
        self.file_list = None
        self.dfs = None

    def check_ext(self, ext):
        if ext != ".csv":
            raise ValueError("Wrong extension, please choose .csv files")
        return ext

    def load_data(self, path):
        return pd.read_csv(path)

    def set_files_in_directory(self):

        files = []
        for file in os.listdir(self.input_dir):
            if file.endswith(self.ext):
                name = self.input_dir + "/" + file
                files.append(name)

        self.file_list = files
        return self.file_list

    def get_sets(self, type):

        df = None
        for element in self.file_list:
            if type in ntpath.abspath(element):
                df = self.load_data(element)
        return df

    def set_dataframes(self):

        df = {}
        types = ["train", "test"]

        if len(self.file_list) == 1:
            df.update({"data": self.load_data(self.file_list[0])})
            return df

        elif len(self.file_list) > 1:
            for type in types:
                df.update({type: self.get_sets(type)})
        else:
            return None

        self.dfs = df
        return self.dfs