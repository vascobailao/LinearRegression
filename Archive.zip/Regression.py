from LinearRegression import Model
import numpy as np
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
mpl.use('TkAgg')
import matplotlib.pyplot as plt


class Regression(Model):

    def __init__(self, dic):
        self.dic = dic
        self.training_data = None
        self.test_data = None
        self.columns_names = None
        self.size = None
        self.x = None
        self.y = None

    def split_data(self):
        if len(self.dic) == 1:
            msk = np.random.rand(len(self.dic["data"])) < 0.8
            self.training_data = self.dic["data"][msk]
            self.test_data = self.dic["data"][~msk]
            return self.training_data, self.test_data

        self.training_data = self.get_trainingData()
        self.test_data = self.get_testData()
        return self.training_data, self.test_data

    def get_size(self):
        return np.size(self.training_data)

    def get_shape(self):
        self.size = self.training_data.shape
        return self.size

    def get_columnNames(self):
        self.columns_names = list(self.training_data.columns.values)
        return self.columns_names

    def get_trainingData(self):
        if self.dic["train"] is None:
            return None
        df = self.dic["train"]
        return df

    def get_testData(self):
        if self.dic["test"] is None:
            return None
        df = self.dic["test"]
        return df

    def get_validationData(self):
        if self.dic["valid"] is None:
            return None
        df = self.dic["valid"]
        return df

    def get_data(self):
        size = len(self.columns_names)
        self.x = np.array(self.training_data.iloc[:, :size-1]).flatten()
        self.y = np.array(self.training_data.iloc[:, size-1]).flatten()
        return self.x, self.y

    def plot_data(self):
        if self.get_shape()[1] == 1:
            plt.plot(self.x, self.y, '.')
            plt.show()

        if self.get_shape()[1] == 2:
            fig = plt.figure()
            ax = Axes3D(fig)
            ax.scatter(self.x[:, 0], self.x[:, 1], self.y, color='#ef1234')
            plt.show()

        else:
            raise ValueError("Data too dimensional to plot")

    def calculate_rmse(self, y, y_hat):
        rmse = np.sqrt(sum((y - y_hat) ** 2) / len(y))
        return rmse

    def calculate_r2(self, y, y_hat):
        mean_y = np.mean(y)
        ss_tot = sum((y - mean_y) ** 2)
        ss_res = sum((y - y_hat) ** 2)
        r2 = 1 - (ss_res / ss_tot)
        return r2